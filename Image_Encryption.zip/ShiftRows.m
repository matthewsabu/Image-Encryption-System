function state = ShiftRows(state)
state(2,:)=circshift(state(2,:),[0 -1]);
state(3,:)=circshift(state(3,:),[0 -2]);
state(4,:)=circshift(state(4,:),[0 -3]);
end